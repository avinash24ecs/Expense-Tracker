# Ledger — Expense Tracker

A full-stack expense tracker: Node.js + Express backend, SQLite database, vanilla HTML/CSS/JS frontend.

## Features
- Add / view / delete expenses (description, amount, category, date)
- Filter by category and by month
- Per-category monthly budgets with progress bars (turns red when over)
- Doughnut chart breakdown of spending by category (Chart.js)
- Totals summary for the selected month

## Project structure
```
expense-tracker/
├── server.js       # Express app + REST API routes
├── db.js           # SQLite setup (better-sqlite3), auto-creates tables on first run
├── package.json
└── public/          # Frontend (served as static files by Express)
    ├── index.html
    ├── style.css
    └── script.js
```

## How to run

1. Make sure you have [Node.js](https://nodejs.org) installed (v18+ recommended).
2. In the project folder, install dependencies:
   ```
   npm install
   ```
3. Start the server:
   ```
   npm start
   ```
4. Open **http://localhost:3000** in your browser.

The database file `expenses.db` is created automatically the first time you run the server, with six default categories (Food, Transport, Housing, Entertainment, Utilities, Other) and no budget limits set.

## API reference

| Method | Route                        | Description                          |
|--------|-------------------------------|---------------------------------------|
| GET    | `/api/expenses?month=&category=` | List expenses, optionally filtered |
| POST   | `/api/expenses`               | Add an expense                       |
| DELETE | `/api/expenses/:id`           | Delete an expense                    |
| GET    | `/api/summary?month=`         | Totals per category for a month      |
| GET    | `/api/budgets`                | List all budgets                     |
| PUT    | `/api/budgets/:category`      | Update a category's monthly limit    |

## Notes for extending it
- Categories currently live as rows in the `budgets` table (a category exists once it has a budget row). To add a new category, insert a row there.
- `db.js` uses Node's `better-sqlite3` — synchronous calls, no promises/callbacks needed, easy to read for a course project.
- No authentication/multi-user support — everything is a single shared ledger, which keeps the project scoped for a mini project. Ask if you want a login system added.
